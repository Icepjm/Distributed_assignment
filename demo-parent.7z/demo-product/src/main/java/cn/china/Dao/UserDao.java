package cn.china.Dao;

import cn.china.entity.User;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface UserDao {
    @Select("select * from user where userId=#{id}")
    public User getUserById(int id);

    @Delete("delete from user where userId=#{id}")
    public int deleteUserById(int id);
    @Insert("insert into user values (#{userId},#{username},#{password},#{email})")
    public boolean addUserById(User user1);
}