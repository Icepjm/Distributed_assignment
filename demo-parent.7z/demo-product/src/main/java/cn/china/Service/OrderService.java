package cn.china.Service;


import cn.china.Dao.OrderDao;
import cn.china.entity.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("OderService")
public class OrderService {
    @Autowired
    private OrderDao orderDao;

    public Order queryOrder(String id){
        return orderDao.getOrderById(id);
    }
    public int deleteOrder(String id){
        return orderDao.deleteOrderById(id);
    }
    public boolean addOrder(Order order)
    {   return orderDao.addOrderById(order);
    }
}
