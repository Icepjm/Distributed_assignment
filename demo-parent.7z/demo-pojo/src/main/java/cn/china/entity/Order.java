package cn.china.entity;

public class Order {

    private String ClassId;
    private String Classname;

    public Order() {
    }

    public Order(String classId, String classname) {
        ClassId = classId;
        Classname = classname;
    }

    public String getClassId() {
        return ClassId;
    }

    public void setClassId(String classId) {
        ClassId = classId;
    }

    public String getClassname() {
        return Classname;
    }

    public void setClassname(String classname) {
        Classname = classname;
    }

    @Override
    public String toString() {
        return "Order{" +
                "ClassId=" + ClassId +
                ", Classname='" + Classname + '\'' +
                '}';
    }
}
