package cn.china.Imp;

import cn.china.Service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
/*
* 业务层（Service Layer）是软件开发中核心逻辑处理的层次，
* 位于 Controller（表现层） 和 DAO/Repository（数据访问层）
* 之间，主要职责是封装业务规则、流程控制和数据处理，确保系统逻辑清晰、可维护。
* */
@Service
public class MailServiceImpl implements MailService {

    @Autowired
    private JavaMailSender mailSender;

    @Override
    public void sendSimpleMail(String to, String subject, String content) {
        SimpleMailMessage message = new SimpleMailMessage();
        // 设置收件人
        message.setTo(to);
        // 设置主题
        message.setSubject(subject);
        // 设置邮件内容
        message.setText(content);
        // 设置发件人，从配置文件中读取
        message.setFrom("2963499398@qq.com");
        mailSender.send(message);
    }
}