package cn.china.Service;

import cn.china.Dao.UserDao;
import cn.china.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("UserService")
public class UserService {

    @Autowired
    private UserDao userDao;

    public User queryUser(int id){
        return userDao.getUserById(id);
    }
    public int delteUser(int id){
        return userDao.deleteUserById(id);
    }
    public boolean addUser(User user)
    {   return userDao.addUserById(user);
    }
}
