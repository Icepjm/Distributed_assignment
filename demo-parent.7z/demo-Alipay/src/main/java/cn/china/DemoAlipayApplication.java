package cn.china;

import cn.china.democommon.FileUtils;
import com.alipay.easysdk.factory.Factory;
import com.alipay.easysdk.kernel.Config;
import com.alipay.easysdk.kernel.util.ResponseChecker;
import com.alipay.easysdk.payment.facetoface.models.AlipayTradePrecreateResponse;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAlipayApplication {

    public static void main(String[] args) throws Exception{

        Factory.setOptions(getOptions());
//        try {
//            // 2. 发起API调用（以创建当面付收款二维码为例）
//            AlipayTradePrecreateResponse response = Factory.Payment.FaceToFace()
//                    .preCreate("Apple iPhone11 128G", "2234567890", "5799.00");
//            // 3. 处理响应或异常
//            if (ResponseChecker.success(response)) {
//                System.out.println("调用成功");
//            } else {
//                System.err.println("调用失败，原因：" + response.msg + "，" + response.subMsg);
//            }
//        } catch (Exception e) {
//            System.err.println("调用遭遇异常，原因：" + e.getMessage());
//            throw new RuntimeException(e.getMessage(), e);
//        }

        SpringApplication.run(DemoAlipayApplication.class, args);
    }
    private static Config getOptions() {
        Config config = new Config();

        config.protocol = "https";

        // 沙箱环境修改为 openapi.alipaydev.com
        config.gatewayHost = "openapi-sandbox.dl.alipaydev.com";

        config.signType = "RSA2";

        config.appId = "9021000149665477";

        // 为避免私钥随源码泄露，推荐从文件中读取私钥字符串而不是写入源码中
        config.merchantPrivateKey = FileUtils.readFileOfTxt("D:\\JXM\\桌面\\分布式\\大作业\\demo-parent\\demo-Alipay\\密码.txt");

        //注：如果采用非证书模式，则无需赋值上面的三个证书路径，改为赋值如下的支付宝公钥字符串即可
        config.alipayPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoWPCOnYo79vB78QSSiviLwsfvqCbygiPryzq4MRBARB5T12bWRIUH+Ta9GgszarHgJk6LsIMrfnnd3udYOH5upOOWIURY5LXcUvphNf1macuBa//PVpB7XrbJd85spoQttwDkg8c97zvGRS31F3CnfrG+AK29C9cuIdHD8Ps7Esw2DEiHJb/zhMr719cjMmz1dQ6PfGdCOnuA6oyKq8/DEc4ihwCgFyamqDPEyd3IwwL1fox9nNMAFUn8FMcm+yZP7/WRMbSKQ+vI2kbp1IU3PrTzf1ClaMg96WMuOTK60SXVBf2L82u3N5h7SBYAv0fFHizbIsZ8eoOscgPEpUsnwIDAQAB";

        //可设置异步通知接收服务地址（可选）（该地址需要外网能够访问）
        config.notifyUrl = "https://1183a90d.r1.cpolar.top";

        return config;
    }
}
