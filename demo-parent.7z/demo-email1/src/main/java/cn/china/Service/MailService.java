package cn.china.Service;


public interface MailService {
    void sendSimpleMail(String to, String subject, String content);
}