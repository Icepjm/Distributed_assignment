package cn.china.Dao;

import cn.china.entity.Order;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface OrderDao {
    @Select("select * from product where classId=#{id}")
    public Order getOrderById(String id);

    @Delete("delete from product where classId=#{id}")
    public int deleteOrderById(String id);
    @Insert("insert into product values (#{ClassId},#{Classname})")
    public boolean addOrderById(Order order1);
}