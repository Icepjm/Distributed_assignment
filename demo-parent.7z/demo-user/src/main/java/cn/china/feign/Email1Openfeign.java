package cn.china.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

/*
* 动态代理实现：
Spring 会在运行时生成该接口的动态代理类，将接口方法转换为实际的 HTTP 请求。
例如调用 email1Openfeign.send("hello") 会发送请求到：
http://email1/sendMail123?content=hello

无需手动实现：
你不需要编写 Email1Openfeign 的实现类，Feign 和 Spring Cloud 会自动处理。
* */
@FeignClient(value = "email1")
public interface Email1Openfeign {
    @RequestMapping("sendMail") // 映射对方服务的API路径
    public String send(@RequestParam("content") String content);
}
