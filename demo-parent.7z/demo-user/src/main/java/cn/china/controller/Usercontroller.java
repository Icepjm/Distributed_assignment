package cn.china.controller;

import cn.china.entity.User;
import cn.china.feign.ProductOpenfeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
public class Usercontroller {
    @Autowired
    ProductOpenfeign productOpenfeign;

        @RequestMapping("getUser")
        public User getuser(@RequestParam("id")int id){return productOpenfeign.getuser(id);}
        @RequestMapping("deleteUser")
        public int deleteuser(@RequestParam("id")int id){return productOpenfeign.deleteuser(id);}
        @RequestMapping("addUser")
        public boolean adduser(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("password") String password,@RequestParam("email") String email)
        {return productOpenfeign.adduser(id,name,password,email);}
        @RequestMapping("/hi")
        public String hello(){
            return productOpenfeign.hello();
        }

}
