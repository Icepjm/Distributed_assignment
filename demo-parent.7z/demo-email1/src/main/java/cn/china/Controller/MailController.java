package cn.china.Controller;

import cn.china.Service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MailController {

    // 接口不依赖实现类，实现类依赖接口
    // 创建接口对象 ，注入接口对象，接口最好只有一个实现类
    @Autowired
    private MailService mailService;

    @GetMapping("/sendMail")
    public String sendMail(@RequestParam("content") String content) {
        String to = "22030428@czu.cn";
        String subject = "测试邮件";
        mailService.sendSimpleMail(to, subject, content);
        return "邮件发送成功！";
    }
}