package cn.china.controller;

import cn.china.Service.UserService;
import cn.china.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @Autowired
    private UserService userService;
    //实现查询页面
    @GetMapping("/getUser")
    public User getUser(@RequestParam("id") int id){
        return userService.queryUser(id);
    }
    @GetMapping("/deleteUser")
    public int deleteUser(@RequestParam("id") int id){
        return userService.delteUser(id);
    }
    @GetMapping("/addUser")
    public boolean addUser(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("password") String password,@RequestParam("email") String email){
        User user =new User();
        user.setUserId(id);
        user.setUsername(name);
        user.setPassword(password);
        user.setEmail(email);
        return userService.addUser(user);
    }
}