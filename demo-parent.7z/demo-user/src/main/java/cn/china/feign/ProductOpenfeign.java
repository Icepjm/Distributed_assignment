package cn.china.feign;

import cn.china.entity.Order;
import cn.china.entity.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

@FeignClient(value = "product")
public interface ProductOpenfeign {
    @RequestMapping("pay/topay")
    public String pay(@RequestParam("subject") String subject, @RequestParam("money")BigDecimal money);
    @RequestMapping("getUser")
    public User getuser(@RequestParam("id") int id);
    @RequestMapping("deleteUser")
    public int deleteuser(@RequestParam("id") int id);
    @RequestMapping("addUser")
    public boolean adduser(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("password") String password,@RequestParam("email") String email);
    @RequestMapping("getOrder")
    public Order getorder(@RequestParam("id") String id);
    @RequestMapping("deleteOrder")
    public int deleteorder(@RequestParam("id") String id);
    @RequestMapping("addOrder")
    public boolean addorder(@RequestParam("id") String id,@RequestParam("name") String name);
    @RequestMapping("/hello")
    public String hello();

}
