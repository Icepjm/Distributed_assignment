package cn.china.controller;

import cn.china.Service.OrderService;
import cn.china.entity.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired
    private OrderService OrderService;
    //实现查询页面
    //调用增删查的方法
    @GetMapping("/getOrder") // 路径匹配 根据地址栏地址找到对应方法
    public Order getOrder(@RequestParam("id") String id){
        return OrderService.queryOrder(id);
    }
    @GetMapping("/deleteOrder")
    public int deleteOrder(@RequestParam("id") String id){
        return OrderService.deleteOrder(id);
    }
    @GetMapping("/addOrder")
    public boolean addOrder(@RequestParam("id") String id,@RequestParam("name") String name){
        Order Order =new Order();
        Order.setClassId(id);
        Order.setClassname(name);
        return OrderService.addOrder(Order);
    }
}