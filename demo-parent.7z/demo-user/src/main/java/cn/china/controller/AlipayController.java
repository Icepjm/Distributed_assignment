package cn.china.controller;

import cn.china.entity.Order;
import cn.china.feign.AlipayOpenfeign;
import cn.china.feign.ProductOpenfeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

@RestController
@CrossOrigin
public class AlipayController {
    @Autowired
    AlipayOpenfeign alipayOpenfeign;
    @RequestMapping("pay/topay")
    public String pay(@RequestParam("subject") String subject,@RequestParam("money") BigDecimal money){
        return alipayOpenfeign.pay(subject,money) ;
    }

}
