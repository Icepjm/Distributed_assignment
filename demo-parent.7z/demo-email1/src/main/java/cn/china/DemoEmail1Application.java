package cn.china;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


// 启动后，Spring Boot 会扫描当前文件夹和子文件夹中的所有类，并自动扫描到所有类中带有@Component、@Service、@Controller等注解的类。
@SpringBootApplication
public class DemoEmail1Application {

    public static void main(String[] args) {
        // 启动应用程序主类，args传入的命令行参数将传递给SpringApplication
        // 主类参数（Spring Boot需要知道从哪里开始启动应用程序）
        // args: 命令行参数 允许在启动时动态传入外部参数

        // 不传命令行参数
        //      不影响应用启动：应用仍然可以正常启动，但你将无法通过命令行动态修改配置。
        //      灵活性降低：你无法在不修改代码的情况下，切换不同的配置文件或修改某些运行时参数。
        SpringApplication.run(DemoEmail1Application.class, args);
    }

}
