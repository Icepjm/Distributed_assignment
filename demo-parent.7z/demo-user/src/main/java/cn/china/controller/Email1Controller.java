package cn.china.controller;


import cn.china.feign.Email1Openfeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
/*
*Feign 是 Spring Cloud 微服务通信的核心组件，通过 声明式接口 + 动态代理
* 隐藏了 HTTP 调用的复杂性，使得 Email1Controller 可以像调用本地方法一样调用远程服务
 * */
/*
类注解：声明式（告诉Spring"这类东西交给你管"）
@Bean：命令式（主动提供一个对象给Spring管理）
*/
    @RestController
    @CrossOrigin
    public class Email1Controller {
        @Autowired
        Email1Openfeign email1Openfeign;
        @RequestMapping("sendMail123")
        public String send(@RequestParam("content") String content){
            return email1Openfeign.send(content) ;
        }

    }