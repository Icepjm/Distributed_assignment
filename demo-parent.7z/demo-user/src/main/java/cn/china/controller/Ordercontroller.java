package cn.china.controller;

import cn.china.entity.Order;
import cn.china.entity.User;
import cn.china.feign.ProductOpenfeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
@CrossOrigin
public class Ordercontroller {
    @Autowired
    ProductOpenfeign productOpenfeign;

    @RequestMapping("getOrder")
    public Order getorder(@RequestParam("id")String id){return productOpenfeign.getorder(id);}
    @RequestMapping("deleteOrder")
    public int deleteorder(@RequestParam("id")String id){return productOpenfeign.deleteorder(id);}
    @RequestMapping("addOrder")
    public boolean addorder(@RequestParam("id") String id,@RequestParam("name") String name)
    {return productOpenfeign.addorder(id,name);}
}
